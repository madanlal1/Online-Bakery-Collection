import "./App.css";
import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";

import Admin from './Admin';

function App() {

  return (
    <>
      {/* <Bar/> */}
      <Admin />
    </>
  );
}

export default App;
